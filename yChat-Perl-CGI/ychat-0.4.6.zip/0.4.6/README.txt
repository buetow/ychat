############################## yChat.de README ##############################
##       Copyright by Paul C. B�tow 200 -  2001 (mail@paulbuetow.de)       ##
#############################################################################

Allgemeine Bedingungen bezgl. yChat:

 - Das yChat-System darf ohne Erleubnis des Autors nicht auf irgendeiner Art
   und Weise weitergegeben- oder eingesetzt werden.

 - Wird das yChat-System eingesetzt, so darf es manipuliert werden, soweit
   die Copyright-Hinweise des Autors, die Versionsbezeichnung und der Link
   auf der Startseite nach servers.yChat.de unver�ndert bleibt.
   Ansonsten darf der gesamte Code manipuliert werden.

 - Wird das yChat-System erlaubter Weise manipuliert, so mu� das ver�nderte
   Skript auf Anforderung an den Autor weitergegeben werden. Dieser darf
   die Ver�nderungen in das Standard-yChat-System integrieren.

 - Wird das yChat-System eingesetzt, su mu� dem Autor die Location bzw. die
   URL bekanntgegeben werden. Diese wird in servers.yChat.de eingetragen.
   und mit einer URL wwX.yChat.de verlinkt. Wobei X f�r die Nummer des jew.
   Servers steht.

 - Es ist verboten, Sourcecode aus dem yChat-System zu kopieren und
   f�r andere, nicht von yChat abh�ngige Perl-Programme einzusetzen.

Im Flogenden einige yChat-bez�gl. Verkn�pfungen:

  www.credits.yChat.de		=> Creditsliste
  www.download.yChat.de		=> Das Skript zum downloaden
  www.readme.yChat.de       	=> Allgemeine Bedingungen usw.
  www.servers.yChat.de     	=> Liste aller laufenden yChat-Systeme
  www.setup.yChat.de        	=> Installationsdokumentation
  www.todo.yChat.de         	=> Funktionen, die sp�ter integriert werden
  www.updates.yChat.de      	=> Update-Liste
  www.yChat.de              	=> Das Skript im Einsatz
