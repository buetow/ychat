############################## yChat.de README ##############################
##      Copyright by Paul C. B�tow 2000 -  2001 (mail@paulbuetow.de)       ##
#############################################################################

Allgemeine Bedingungen bzgl. yChat:

 1. Das yChat-System in den Versionen 0.6.X und fr�her ist Freeware und darf
    kostenlos weitergeben und eingesetzt werden. 

 2. Ohne Einwilligung des Autors darf mit dem Skript auf irgend welche Art
    kein Geld verdient werden.

 3. Wird das yChat-System eingesetzt, so darf es manipuliert werden, soweit
    die Copyright-Hinweise des Autors (/about) und die Versionsbezeichnung 
    auf der Startseite enthalten bleiben.

 4. Wird das yChat-System manipuliert, so mu� das ver�nderte Skript auf 
    Anforderung an den Autor weitergegeben werden. Dieser darf die 
    Ver�nderungen in das Standard-yChat-System integrieren.

 5. Wird das yChat-System eingesetzt, so mu� dem Autor die Location bzw. die
    URL bekanntgegeben werden. Auf Wunsch wird dort eine Subdomain
    DEINNAME.yChat.de gelinkt.

 6. Es ist verboten, Sourcecode aus dem yChat-System zu kopieren und
    f�r andere, nicht von yChat abh�ngige Perl-Programme einzusetzen.

 7. Der Autor �bernimmt keine Haftung �ber das Skript oder die Folgen der
    Einsetzung des Skripts und leistet keinen Installationssupport.    