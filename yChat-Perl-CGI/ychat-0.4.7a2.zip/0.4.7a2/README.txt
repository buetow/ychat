############################## yChat.de README ##############################
##      Copyright by Paul C. B�tow 2000 -  2001 (mail@paulbuetow.de)       ##
#############################################################################

Allgemeine Bedingungen bezgl. yChat:

 - Das yChat-System darf ohne Erleubnis des Autors nicht auf irgendeiner Art
   und Weise weitergegeben- oder eingesetzt werden.

 - Wird das yChat-System eingesetzt, so darf es manipuliert werden, soweit
   die Copyright-Hinweise des Autors, die Versionsbezeichnung und der Link
   auf der Startseite nach www.home.yChat.de unver�ndert bleibt.
   Ansonsten darf der gesamte Code manipuliert werden.

 - Wird das yChat-System erlaubter Weise manipuliert, so mu� das ver�nderte
   Skript auf Anforderung an den Autor weitergegeben werden. Dieser darf
   die Ver�nderungen in das Standard-yChat-System integrieren.

 - Wird das yChat-System eingesetzt, su mu� dem Autor die Location bzw. die
   URL bekanntgegeben werden. Diese mit einer URL wwX.yChat.de verlinkt. 
   Wobei X f�r die Nummer des jew. Servers steht.

 - Es ist verboten, Sourcecode aus dem yChat-System zu kopieren und
   f�r andere, nicht von yChat abh�ngige Perl-Programme einzusetzen.